# Naive Bayes
# El primer paso es importar las librerías de machine learning necesarias
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importacion del dataset
dataset = pd.read_csv('Social_Network_Ads.csv')
print(dataset)
X = dataset.iloc[:, [2, 3]].values
y = dataset.iloc[:, 4].values
dataset

#Ahora dividimos el conjunto de datos en un subconjunto de entrenamiento y un subconjunto de pruebas
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, 
                                                    test_size = 0.25, 
                                                    random_state = 0)

#Después de crear el conjunto de entranamiento y el de pruebas, ahora estandarizamos las escala
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)


# Ya con las escalas estandarizadas, ahora creamos el modelo con la clase KNeighborsClassifier del paquete sklearn
# Esta clase es la que nos permite utilizar el clasificador de Naive Bayes
# Creacion del modelo Naive Bayes y entrenamiento del mismo
from sklearn.naive_bayes import GaussianNB
classifier = GaussianNB()
classifier.fit(X_train, y_train)

# GaussianNB(priors=None, var_smoothing=1e-09)

# Hacemos la predicción del conjunto de pruebas

# Prediccion del conjunto de prueba
y_pred = classifier.predict(X_test)


#Con ello generamos la matriz de confusión
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)
# print(cm)

# Salida de la matriz de confusion
# En la matriz de confusión observamos que hay 3 falsos negativos y 7 falsos positivos,
# en total 10 errores de una muestra de 100, por lo que tenemos una precisión del 90%
# array([[65,  3],
#       [ 7, 25]], dtype=int64)

# Graficamos los resultados de predicción contra los del conjunto de pruebas
# Visualizacion de los datos de prueba
from matplotlib.colors import ListedColormap
X_set, y_set = X_test, y_test
X1, X2 = np.meshgrid(np.arange(start = X_set[:, 0].min() - 1, stop = X_set[:, 0].max() + 1, step = 0.01),
                     np.arange(start = X_set[:, 1].min() - 1, stop = X_set[:, 1].max() + 1, step = 0.01))
plt.contourf(X1, X2, classifier.predict(np.array([X1.ravel(), X2.ravel()]).T).reshape(X1.shape),
             alpha = 0.75, cmap = ListedColormap(['r', 'g']))
plt.xlim(X1.min(), X1.max())
plt.ylim(X2.min(), X2.max())
for i, j in enumerate(np.unique(y_set)):
    plt.scatter(X_set[y_set == j, 0], X_set[y_set == j, 1], c = ListedColormap(['r', 'g'])(i), label = j)
plt.title('Naive Bayes (Datos de prueba)')
plt.xlabel('Edad')
plt.ylabel('Salario Estimado')
plt.legend()
plt.show()
