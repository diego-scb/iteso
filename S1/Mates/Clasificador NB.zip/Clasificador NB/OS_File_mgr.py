import os

print(os.getcwd())
#os.chdir('Proyectos/Naive_Bayes_Clasiffier')            # entro en ../Data
print(os.getcwd())
